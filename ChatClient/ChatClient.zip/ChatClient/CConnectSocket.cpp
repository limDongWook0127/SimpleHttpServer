#include "pch.h"
#include "CConnectSocket.h"
#include "ChatClientDlg.h"
#include <vector>
#include <algorithm>    // std::min

int CConnectSocket::SendAll(const void* buf, int len)
{
    const char* p = static_cast<const char*>(buf);
    int total = 0;
    while (total < len)
    {
        int n = Send(p + total, len - total);
        if (n == SOCKET_ERROR) return SOCKET_ERROR;
        total += n;
    }
    return total;
}

int CConnectSocket::RecvAll(void* buf, int len)
{
    char* p = static_cast<char*>(buf);
    int total = 0;
    while (total < len)
    {
        int n = Receive(p + total, len - total);
        if (n <= 0) return n; // 0: ����, -1: ����
        total += n;
    }
    return total;
}

void CConnectSocket::OnClose(int nErrorCode)
{
    ShutDown();
    Close();
    CSocket::OnClose(nErrorCode);

    AfxMessageBox(L"ERROR: Disconnected from server");
    ::PostQuitMessage(0);
}

void CConnectSocket::OnReceive(int nErrorCode)
{
    
    BYTE buffer[4096] = { 0 };
    int nLen = Receive(buffer, sizeof(buffer));
    if (nLen <= 0) { CSocket::OnReceive(nErrorCode); return; }

    CChatClientDlg* pMain = (CChatClientDlg*)AfxGetMainWnd();
    if (!pMain)
    {
        return;
    }
    {
        std::lock_guard<std::mutex> lock(pMain->m_queueMutex);
        pMain->m_recvQueue.push(std::vector<BYTE>(buffer, buffer + nLen));
    }
    pMain->m_cv.notify_one();

    CSocket::OnReceive(nErrorCode);
}

void CConnectSocket::SendFile(LPCTSTR lpszFilePath)
{
    CFile file;
    if (!file.Open(lpszFilePath, CFile::modeRead | CFile::typeBinary))
    {
        AfxMessageBox(L"���� ���� ����");
        return;
    }

    FileHeader header{};
    header.type = 1;
    header.fileSize = static_cast<uint32_t>(file.GetLength());

    CString fileName = PathFindFileName(lpszFilePath);
    CT2A fileNameA(fileName, CP_UTF8);
    strcpy_s(header.fileName, _countof(header.fileName), fileNameA);

    if (SendAll(&header, sizeof(header)) == SOCKET_ERROR)
    {
        AfxMessageBox(L"��� ���� ����");
        file.Close();
        return;
    }

    std::vector<BYTE> buffer(1024 * 64);
    UINT bytesRead = 0;
    while ((bytesRead = file.Read(buffer.data(), (UINT)buffer.size())) > 0)
    {
        if (SendAll(buffer.data(), bytesRead) == SOCKET_ERROR)
        {
            AfxMessageBox(L"���� ���� �� ����");
            file.Close();
            return;
        }
    }

    file.Close();
    AfxMessageBox(L"���� ���� �Ϸ�");
}

bool CConnectSocket::IsFileHeader(BYTE* buffer, int nLen)
{
    if (nLen < (int)sizeof(uint32_t)) return false;  // type���� ����
    uint32_t type = *(uint32_t*)buffer;
    return (type == 1);
}

/
