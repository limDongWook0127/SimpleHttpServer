#pragma once
#include <afxdialogex.h>
#include "resource.h"
class CNickNameDlg :
    public CDialogEx
{
    DECLARE_DYNAMIC(CNickNameDlg)

public:
    CString m_NickName;
    CNickNameDlg(CWnd* pParent = nullptr)
        : CDialogEx(IDD_INPUTNICKNAME, pParent) { } //IDD_INPUTGNICKNAME �̶�� ���̾�α� ���ҽ��� ���ڴٴ� ��
protected:
    virtual void DoDataExchange(CDataExchange* pDX);
   

    DECLARE_MESSAGE_MAP()
};

