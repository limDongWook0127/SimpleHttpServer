#pragma once

#pragma pack(push, 1)
struct FileHeader
{
    uint32_t type;          // 1 = file
    uint32_t fileSize;      // (2GB �̻��̸� uint64_t �� �ٲ�)
    char     fileName[256];     // ���ϸ� (ASCII or UTF-8)
};
#pragma pack(pop)